async function insertion(){
    console.log('In insertion()');
    const obj = document.querySelectorAll(".bar");
    // color
    obj[0].style.background = 'yellow';
    for(let i = 1; i < obj.length; i++){
        console.log('In ith loop');
        let j = i - 1;
        let key = obj[i].style.height;
        // color
        obj[i].style.background = 'red';

        await waitforme(delay);

        while(j >= 0 && (parseInt(obj[j].style.height) > parseInt(key))){
            console.log('In while loop');
            // color
            obj[j].style.background = 'red';
            obj[j + 1].style.height = obj[j].style.height;
            j--;

            await waitforme(delay);

            // color
            for(let k = i; k >= 0; k--){
                obj[k].style.background = 'yellow';
            }
        }
        obj[j + 1].style.height = key;
        // color
        obj[i].style.background = 'yellow';
    }
}

const inSortbtn = document.querySelector(".insertionSort");
inSortbtn.addEventListener('click', async function(){
    disableSortingBtn();
    disableSizeSlider();
    disableNewArrayBtn();
    await insertion();
    enableSortingBtn();
    enableSizeSlider();
    enableNewArrayBtn();
});



