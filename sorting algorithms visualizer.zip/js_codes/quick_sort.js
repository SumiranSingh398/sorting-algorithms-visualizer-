async function partitionLomuto(obj, l, r){
    console.log('In partitionLomuto()');
    let i = l - 1;
    // color pivot element
    obj[r].style.background = 'red';
    for(let j = l; j <= r - 1; j++){
        console.log('In partitionLomuto for j');
        // color current element
        obj[j].style.background = 'yellow';
        // pauseChamp
        await waitforme(delay);

        if(parseInt(obj[j].style.height) < parseInt(obj[r].style.height)){
            console.log('In partitionLomuto for j if');
            i++;
            swap(obj[i], obj[j]);
            // color 
            obj[i].style.background = 'orange';
            if(i != j) obj[j].style.background = 'orange';
            // pauseChamp
            await waitforme(delay);
        }
        else{
            // color if not less than pivot
            obj[j].style.background = 'pink';
        }
    }
    i++; 
    // pauseChamp
    await waitforme(delay);
    swap(obj[i], obj[r]); // pivot height one
    console.log(`i = ${i}`, typeof(i));
    // color
    obj[r].style.background = 'pink';
    obj[i].style.background = 'green';

    // pauseChamp
    await waitforme(delay);
    
    // color
    for(let k = 0; k < obj.length; k++){
        if(obj[k].style.background != 'green')
            obj[k].style.background = 'cyan';
    }

    return i;
}

async function quickSort(obj, l, r){
    console.log('In quickSort()', `l=${l} r=${r}`, typeof(l), typeof(r));
    if(l < r){
        let pivot_index = await partitionLomuto(obj, l, r);
        await quickSort(obj, l, pivot_index - 1);
        await quickSort(obj, pivot_index + 1, r);
    }
    else{
        if(l >= 0 && r >= 0 && l <obj.length && r <obj.length){
            obj[r].style.background = 'green';
            obj[l].style.background = 'green';
        }
    }
}


const quickSortbtn = document.querySelector(".quickSort");
quickSortbtn.addEventListener('click', async function(){
    let obj = document.querySelectorAll('.bar');
    let l = 0;
    let r = obj.length - 1;
    disableSortingBtn();
    disableSizeSlider();
    disableNewArrayBtn();
    await quickSort(obj, l, r);
    enableSortingBtn();
    enableSizeSlider();
    enableNewArrayBtn();
});
